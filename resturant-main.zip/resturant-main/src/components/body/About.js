import React from 'react';

const About = () => {
    document.title = "About";
    return (
        <div>

        </div>
    );
}

export default About;