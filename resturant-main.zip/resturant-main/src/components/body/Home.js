import React, { Component } from 'react';

class Home extends Component {
    render() {
        document.title = "Bohubrihi Restaurant";
        return (
            <div>

            </div>
        );
    }
}

export default Home;